import sys
import math
import numpy as np
import copy
import time
import heapq
import datetime

class PriorityQueue:
    #int
    def __init__(self):
        self.heap = []
        self.count = 0
    #push 
    def push(self, item, priority):
        entry = (priority, self.count, item)
        heapq.heappush(self.heap, entry)
        self.count += 1
    #pop
    def pop(self):
        (_, _, item) = heapq.heappop(self.heap)
        return item
    # is empty
    def isEmpty(self):
        return len(self.heap) == 0
    #refresh
    def update(self, item, priority):

        for index, (p, c, i) in enumerate(self.heap):
            if i == item:
                if p <= priority:
                    break
                del self.heap[index]
                self.heap.append((priority, c, item))
                heapq.heapify(self.heap)
                break
        else:
            self.push(item, priority)

class Node():
    def __init__(self,state,parent,gn,hn,element = 0):
        self.state = state  #board state
        self.parent = parent #parent node
        self.gn = gn  #current cost
        self.hn = hn #heuristic value
        self.fn = gn + hn #estimilate value
        self.element = element #last move element 

def A_star(start_node,dst_node,target,move):

    close_queue = [] #已访问的结点集合
    close_queue.append(start_node.state)

    open_queue = PriorityQueue() #优先队列初始化
    open_queue.push(start_node,0)  #插入根结点
    #print(heuristic_manhadun(start_node.state,target))

    while open_queue:

        node = open_queue.pop() #出队，选fn最小的结点
        #print(node.gn,node.fn)
        #如果是目标状态，返回当前结点
        if node.state == dst_node.state:
            return node

        for i in range(len(node.state)):
            for j in range(len(node.state[0])):
                if node.state[i][j] == 0:
                    move_x = i
                    move_y = j
                    break
        for movement in move:
            x = move_x + movement[0] #更新x
            y = move_y + movement[1] #更新y
            if  move_x == 0 and move_y == 2 and movement[0] == -1 and movement[1] == 0:
                    x = 4
                    y = 2
            if  move_x == 4 and move_y == 2 and movement[0] == 1 and movement[1] == 0:
                    x = 0
                    y = 2
            if  move_x == 2 and move_y == 0 and movement[0] == 0 and movement[1] == -1:
                    x = 2
                    y = 4
            if  move_x == 2 and move_y == 4 and movement[0] == 0 and movement[1] == 1:
                    x = 2
                    y = 0           
            #越界探测
            if x >= 5 or x < 0 or y >= 5 or y < 0:
                continue
            
            #保证不走回头路
            if node.state[x][y] == node.element:
                continue
            new_state = copy.deepcopy(node.state) #深复制，避免影响上一个结点
            new_state[move_x][move_y] = new_state[x][y] #移动位置
            new_state[x][y] = 0 #更换0的位置
            #element = new_state[move_x][move_y] #存储移动的元素数值

            gn = node.gn+1 #成本加1
            hn = heuristic_manhadun(new_state, target) #求估计代价
            #hn = heuristic_count_misplace(new_state, target) #求估计代价
            if movement[0] == 0 and movement[1] == 1:
                element = 'R' 
            if movement[0] == 0 and  movement[1] == -1:
                element = 'L' 
            if movement[0] == 1 and movement[1] == 0:
                element = 'D'   
            if movement[0] == -1 and movement[1] == 0:
                element = 'U'
            new_node = Node(new_state,node,gn,hn,element) #创建新结点  
            #如果新结点状态已经探测，则放弃该方向扩展
            if new_node.state in close_queue:
                continue
            #否则进行扩展，置为已经访问
            else:
                close_queue.append(node.state)
                open_queue.push(new_node,new_node.fn)

    return None

def heuristic_manhadun(state,target):
    current_array = state  #矩阵状态
    length_x = len(current_array)
    length_y = len(current_array[0]) #计算矩阵的size
    dist = 0
    for i in range(length_x):
        for j in range(length_y):
            if (current_array[i][j] != 0): #except for element 0
                x,y = target[current_array[i][j]]
                if i < 2 and x > 2:
                    dist += min(5-x+i + abs (2-j)+abs(y-2),(abs(x - i) + abs(y - j)))
                    continue
                if i > 2 and x < 2:
                    dist += min(x + 5 -i + abs (2-j)+abs(y-2),(abs(x - i) + abs(y - j)))
                    continue
                if j < 2 and y > 2:
                    dist  +=  min(abs(2-i) +abs(x-2)+5-y+j,(abs(x - i) + abs(y - j)))
                    continue
                if j > 2 and y < 2:
                    dist  += min(abs(2-i)+abs(x-2) + 5-j+y,(abs(x - i) + abs(y - j)))
                    continue
                dist += (abs(x - i) + abs(y - j))
    return dist


def heuristic_count_misplace(state,target):
    current_array = state
    length_x = len(current_array)
    length_y = len(current_array[0])
    dist = 0
    for i in range(length_x):
        for j in range(length_y):
            x,y = target[current_array[i][j]]
            if x==i and y == j:
                continue
            else:
                dist+=1

    return dist

def main() :
    start = datetime.datetime.now()
    # file_name = "sample_input.txt"
    file_name = "input1.txt"
    with open (file_name,'r',encoding="utf-8") as file1:
        sample_list = file1.readlines()

    for i in range(len(sample_list)):
        tmp = sample_list[i].split()
        sample_list[i] = [int(x) for x in tmp]

    array_number = 1
    array_size = 5
    end_state = []
    number = 1
    file_name2 = "target.txt"
    with open (file_name2,'r',encoding="utf-8") as file2:
        sample_list2 = file2.readlines()
    for i in range(len(sample_list2)):
        tmp = sample_list2[i].split()
        sample_list2[i] = [int(x) for x in tmp]
    #print(sample_list2)
    endnode = copy.deepcopy(sample_list2)
    # print(end_state)
    dst_node = Node(endnode,None,0,0)

    target = {}
    number = 1
    target[0] = (array_size-1,array_size-1)
    for i in range(array_size):
        for j in range(array_size):
             target[endnode[i][j]] = (i,j)

    move = [[1,0],[0,1],[-1,0],[0,-1]]

    digital_array = copy.deepcopy(sample_list[0:array_size])
    start_node = Node(digital_array,None,0,0)
        # print(digital_array)
    result = A_star(start_node,dst_node,target,move)
    if result != None:
        print("move step: ",result.gn)
        road = []
        while result:
                # array = np.array(result.state)
                # print(array)
            road.append(result.element)
            result = result.parent
        road = list(reversed(road))
        print(road[1:])
        end = datetime.datetime.now()
        print("run time : " ,str((end - start).total_seconds()),' s')
        file_name3 = "Ah2_solution.txt"
        length = len(road)
        s=''
        for i in range(1,length):
            s += str(road[i])
        print(s)
        with open (file_name3,'w',encoding = "utf-8") as file3:
            file3.write(str((end - start).total_seconds())+'s'+'\n')
            file3.write(s+'\n')
            file3.write(str(length-1))
if __name__ == "__main__":
    main()