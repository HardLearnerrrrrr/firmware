import sys
import math
import numpy as np
import copy
import time
import heapq
import datetime

class Node():
    def __init__(self,state,parent,gn,hn,element = 0):
        self.state = state
        self.parent = parent
        self.gn = gn
        self.hn = hn
        self.fn = gn*1+ hn
        self.element = element

def choose_successor(node,target,move):
    for i in range(len(node.state)):
        for j in range(len(node.state[0])):
            if node.state[i][j] == 0:
                move_x = i
                move_y = j
                break
    success_list = []
    for movement in move:
        x = move_x + movement[0] #更新x
        y = move_y + movement[1] #更新y
        if  move_x == 0 and move_y == 2 and movement[0] == -1 and movement[1] == 0:
            x = 4
            y = 2
        if  move_x == 4 and move_y == 2 and movement[0] == 1 and movement[1] == 0:
            x = 0
            y = 2
        if  move_x == 2 and move_y == 0 and movement[0] == 0 and movement[1] == -1:
            x = 2
            y = 4
        if  move_x == 2 and move_y == 4 and movement[0] == 0 and movement[1] == 1:
            x = 2
            y = 0     
            #越界探测
        if x >= 5 or x < 0 or y >= 5 or y < 0:
            continue  
        #判断是否走回头路
        if node.state[x][y] == node.element:
            continue
        new_state = copy.deepcopy(node.state) #深复制
        new_state[move_x][move_y] = new_state[x][y] #移动元素
        new_state[x][y] = 0 #移动空格
        element = new_state[move_x][move_y] #记录移动的元素
        gn = node.gn+1 #改变实际代价
        hn = heuristic_manhadun(new_state, target) #求估计代价
        # hn = heuristic_chebyshev_distance(new_state,target)
        if movement[0] == 0 and movement[1] == 1:
            new_node = Node(new_state,node,gn,hn,'R') #创建新结点
        if movement[0] == 0 and  movement[1] == -1:
            new_node = Node(new_state,node,gn,hn,'L') #创建新结点 
        if movement[0] == 1 and movement[1] == 0:
            new_node = Node(new_state,node,gn,hn,'D') #创建新结点   
        if movement[0] == -1 and movement[1] == 0:
            new_node = Node(new_state,node,gn,hn,'U') #创建新结点       
        success_list.append(new_node) #加入队列
    #对扩展的3个方向进行选择，按照fn从小到大
    return sorted(success_list,key = lambda x : x.fn)

def A_DFS(open_queue,g,bound,close_queue,target,move,dst_node):

    node = open_queue[-1] #取最后入队的一个结点进行扩展
    #print(node.gn,node.fn)
    if node.state == dst_node.state: #如果到达目标状态，返回
        return -2

    min_limit = 10000 #找出最小的估价函数值
    #按照fn从小到达选择要扩展的方向
    for succ in choose_successor(node,target,move):
        new_node = succ
        isvisit = 0
        #判断结点是否在开启队列中
        for node1 in open_queue:
            if new_node.state == node1.state:
                isvisit = 1
                break
        if isvisit == 1:
            continue
        else:
            #判断结点是否在关闭队列中
            if new_node.state in close_queue:
                continue
            #如果新结点的fn大于阈值，停止扩展，返回
            if new_node.fn > bound:
                return new_node.fn
            #添加结点到关闭队列
            close_queue.append(new_node.state)
            #添加结点到开启队列
            open_queue.append(new_node)
            #递归调用A_DFS函数
            result = A_DFS(open_queue,g+1,bound,close_queue,target,move,dst_node)
            #如果找到结果，直接返回-2
            if result == -2:
                return result
            #否则比较当前的估价函数值，得出最小的更新到min_limit
            elif result < min_limit:
                min_limit = result
            open_queue.pop(-1) #出队，恢复
            close_queue.pop(-1) #出队，恢复

    return min_limit #返回最小的估价函数值

def IDA(start_node,dst_node,target,move):
    bound = heuristic_manhadun(start_node.state,target) #以初始点到终点的估价函数值为阈值
    open_queue = [] #开启列表
    open_queue.append(start_node) #初始点入队
    while True:
        #print(bound)
        close_queue = [] #关闭列表
        close_queue.append(start_node.state) #初始点置为已经访问
        #将阈值作为探索的深度，调用以DFS为基础的A*算法函数
        result = A_DFS(open_queue,0,bound,close_queue,target,move,dst_node)
        #结果等于-2，则找到正确结果
        if result == -2:
            return open_queue
        #超过一定深度，不再探索
        if result > 100:
            return None
        #将返回的估计函数最小值作为下一次迭代的阈值
        bound = result
    return None

#count the distance which is simulate to manhadun
def heuristic_manhadun(state,target):
    current_array = state  #矩阵状态
    length_x = len(current_array)
    length_y = len(current_array[0]) #计算矩阵的size
    dist = 0
    for i in range(length_x):
        for j in range(length_y):
            if (current_array[i][j] != 0): #except for element 0
                x,y = target[current_array[i][j]]
                if i < 2 and x > 2:
                    dist += min(5-x+i + abs (2-j)+abs(y-2),(abs(x - i) + abs(y - j)))
                    continue
                if i > 2 and x < 2:
                    dist += min(x + 5 -i + abs (2-j)+abs(y-2),(abs(x - i) + abs(y - j)))
                    continue
                if j < 2 and y > 2:
                    dist  +=  min(abs(2-i) +abs(x-2)+5-y+j,(abs(x - i) + abs(y - j)))
                    continue
                if j > 2 and y < 2:
                    dist  += min(abs(2-i)+abs(x-2) + 5-j+y,(abs(x - i) + abs(y - j)))
                    continue
                dist += (abs(x - i) + abs(y - j))
    return dist

#count the misplace element,this is h1 function
def heuristic_count_misplace(state,target):
    current_array = state
    length_x = len(current_array)
    length_y = len(current_array[0])
    dist = 0
    for i in range(length_x):
        for j in range(length_y):
            x,y = target[current_array[i][j]]
            if x==i and y == j:
                continue
            else:
                dist+=1

    return dist

def main() :
    start = datetime.datetime.now()
    # file_name = "sample_input.txt"
    file_name = "input1.txt"
    with open (file_name,'r',encoding="utf-8") as file1:
        sample_list = file1.readlines()

    for i in range(len(sample_list)):
        tmp = sample_list[i].split()
        sample_list[i] = [int(x) for x in tmp]
    array_size = 5

    end_state = []
    number = 1
    file_name2 = "target.txt"
    with open (file_name2,'r',encoding="utf-8") as file2:
        sample_list2 = file2.readlines()
    for i in range(len(sample_list2)):
        tmp = sample_list2[i].split()
        sample_list2[i] = [int(x) for x in tmp]
    
    endnode = copy.deepcopy(sample_list2)
    dst_node = Node(endnode,None,0,0,'U')

    target = {}
    number = 1

    for i in range(array_size):
        for j in range(array_size):
            target[endnode[i][j]] = (i,j)
    #print(target)

    move = [[1,0],[0,1],[-1,0],[0,-1]]

    digital_array = copy.deepcopy(sample_list[0:array_size])
    start_node = Node(digital_array,None,0,0,'U')
        # print(digital_array)
    result = IDA(start_node,dst_node,target,move)
    if result != None:
        print("move step: ",result[-1].gn)
        road = []
        for node in result:
            array = np.array(node.state)
                #print(array)
                #print(node.gn)
            road.append(node.element)
        print(road[1:])
        end = datetime.datetime.now()
        print("run time : " ,str((end - start).total_seconds()),'s')
        file_name3 = "IDAh2_solution.txt"
        length = len(road)
        s=''
        for i in range(1,length):
            s += str(road[i])
        print(s)
        with open (file_name3,'w',encoding = "utf-8") as file3:
            file3.write(str((end - start).total_seconds())+'s'+'\n')
            file3.write(s+'\n')
            file3.write(str(length-1))

if __name__ == "__main__":
    main()