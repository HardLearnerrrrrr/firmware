#include "./player.h"
MimicsPlayer::MimicsPlayer(){
	card_total = 0; //needs to be set because will ++
	bet = 0;
	money = 0;
} 
MimicsPlayer::~MimicsPlayer(){
}

bool MimicsPlayer::choose_stay(deck &d)
{
	//p_hand.add_card(d.remove_card()); //similar to Parham demo
	int card_total = p_hand.count_total(p_hand);
	cout << "MimicsPlayer card_total " << card_total << endl;
	if(card_total>16)
		return true;
	else if(card_total<=16)
		return false;
}
class MimicsGreenPlayer:public MimicsPlayer{
	public:
	MimicsGreenPlayer();
	~MimicsGreenPlayer();
};
class MimicsBlackPlayer:public MimicsPlayer{
	public:
	MimicsBlackPlayer();
	~MimicsBlackPlayer();
};
class MimicsBluePlayer:public MimicsPlayer{
	public:
	MimicsBluePlayer();
	~MimicsBluePlayer();
};
class MimicsRedPlayer:public MimicsPlayer{
	public:
	MimicsRedPlayer();
	~MimicsRedPlayer();
};

MimicsGreenPlayer::MimicsGreenPlayer(){
	card_total = 0; //needs to be set because will ++
	bet = 0;
	money = 0;
}
MimicsGreenPlayer::~MimicsGreenPlayer(){

}
MimicsRedPlayer::MimicsRedPlayer(){
	card_total = 0; //needs to be set because will ++
	bet = 0;
	money = 0;
}
MimicsRedPlayer::~MimicsRedPlayer(){
	
}
MimicsBluePlayer::MimicsBluePlayer(){
	card_total = 0; //needs to be set because will ++
	bet = 0;
	money = 0;
}
MimicsBluePlayer::~MimicsBluePlayer(){
	
}
MimicsBlackPlayer::MimicsBlackPlayer(){
	card_total = 0; //needs to be set because will ++
	bet = 0;
	money = 0;
}
MimicsBlackPlayer::~MimicsBlackPlayer(){
	
}