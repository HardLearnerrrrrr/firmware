#include "./player.h"
SafePlayer::SafePlayer(){
	card_total = 0; //needs to be set because will ++
	bet = 0;
	money = 0;
}
SafePlayer::~SafePlayer(){
}
bool SafePlayer::choose_stay(deck &d)
{
	//p_hand.add_card(d.remove_card()); //similar to Parham demo
	int card_total = p_hand.count_total(p_hand);
	cout << "SafePlayer:card_total:" << card_total << endl;
	if(card_total>11)
		return true;
	else if(card_total<=11)
		return false;
		//return false;
	return true;
};
class SafeGreenPlayer:public SafePlayer{
	public:
	SafeGreenPlayer();
	~SafeGreenPlayer();
};
class SafeBlackPlayer:public SafePlayer{
	public:
	SafeBlackPlayer();
	~SafeBlackPlayer();
};
class SafeBluePlayer:public SafePlayer{
	public:
	SafeBluePlayer();
	~SafeBluePlayer();
};
class SafeRedPlayer:public SafePlayer{
	public:
	SafeRedPlayer();
	~SafeRedPlayer();
};

SafeGreenPlayer::SafeGreenPlayer(){
	card_total = 0; //needs to be set because will ++
	bet = 0;
	money = 0;
}
SafeGreenPlayer::~SafeGreenPlayer(){

}
SafeRedPlayer::SafeRedPlayer(){
	card_total = 0; //needs to be set because will ++
	bet = 0;
	money = 0;
}
SafeRedPlayer::~SafeRedPlayer(){
	
}
SafeBluePlayer::SafeBluePlayer(){
	card_total = 0; //needs to be set because will ++
	bet = 0;
	money = 0;
}
SafeBluePlayer::~SafeBluePlayer(){
	
}
SafeBlackPlayer::SafeBlackPlayer(){
	card_total = 0; //needs to be set because will ++
	bet = 0;
	money = 0;
}
SafeBlackPlayer::~SafeBlackPlayer(){
	
}