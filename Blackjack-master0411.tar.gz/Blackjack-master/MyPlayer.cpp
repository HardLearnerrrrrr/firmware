#include "./player.h"
MyPlayer::MyPlayer(){
	card_total = 0; //needs to be set because will ++
	bet = 0;
	money = 0;
}
MyPlayer::~MyPlayer(){
}
bool MyPlayer::choose_stay(deck &d)
{
	//p_hand.add_card(d.remove_card()); //similar to Parham demo
	int card_total = p_hand.count_total(p_hand);
	cout << "MyPlayer:card_total:" << card_total << endl;
	if(card_total>11)
		return true;
	else if(card_total<=11)
		return false;
		//return false;
	return true;
}
class MyGreenPlayer:public MyPlayer{
	public:
	MyGreenPlayer();
	~MyGreenPlayer();
};
class MyBlackPlayer:public MyPlayer{
	public:
	MyBlackPlayer();
	~MyBlackPlayer();
};
class MyBluePlayer:public MyPlayer{
	public:
	MyBluePlayer();
	~MyBluePlayer();
};
class MyRedPlayer:public MyPlayer{
	public:
	MyRedPlayer();
	~MyRedPlayer();
};

MyGreenPlayer::MyGreenPlayer(){
	card_total = 0; //needs to be set because will ++
	bet = 0;
	money = 0;
}
MyGreenPlayer::~MyGreenPlayer(){

}
MyRedPlayer::MyRedPlayer(){
	card_total = 0; //needs to be set because will ++
	bet = 0;
	money = 0;
}
MyRedPlayer::~MyRedPlayer(){
	
}
MyBluePlayer::MyBluePlayer(){
	card_total = 0; //needs to be set because will ++
	bet = 0;
	money = 0;
}
MyBluePlayer::~MyBluePlayer(){
	
}
MyBlackPlayer::MyBlackPlayer(){
	card_total = 0; //needs to be set because will ++
	bet = 0;
	money = 0;
}
MyBlackPlayer::~MyBlackPlayer(){
	
}