#include "./hand.h"
#include "./deck.h" 

class player{
	public:
	   	hand p_hand; //player hand
		int money;
		int card_total; //total value of cards in hand
		int bet;
	public:
		player();
	       	~player();
		void set_money(int);
	       	int get_money();
		void make_bet(); //when dealer asks for bet
		int get_card_total(); 
		int get_bet(); //gives player's bet
		void get_inital_hand(deck &); //gets hand, changes deck
		void print_hand();
		void hit(deck &, bool &); 
		void determine_bust(); 
		void won();
		void lost(); 	
		void tie(); 
		virtual bool choose_stay(deck &d);
};
class RandomPlayer: public player{
	public:
	RandomPlayer();
	       	~RandomPlayer();
	bool choose_stay(deck &d);
};

 class SafePlayer: public player{
	public:
	SafePlayer();
	       	~SafePlayer();
	bool  choose_stay(deck &d);
};
class MimicsPlayer: public player{
	
	public:
	MimicsPlayer();
	       	~MimicsPlayer();
	bool choose_stay(deck &d);
};
 class MyPlayer: public player{
	public:
	bool  choose_stay(deck &d);
};
