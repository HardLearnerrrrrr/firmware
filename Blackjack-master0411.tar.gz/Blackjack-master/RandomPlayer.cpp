#include "./player.h"
RandomPlayer::RandomPlayer(){
	card_total = 0; //needs to be set because will ++
	bet = 0;
	money = 0;
} 

RandomPlayer::~RandomPlayer(){
}



bool RandomPlayer::choose_stay(deck &d)
{
	//p_hand.add_card(d.remove_card()); //similar to Parham demo
	int card_total = p_hand.count_total(p_hand);
	cout << "randomPlayer cardtotal" << card_total << endl;
	if(card_total<=11)
		return false;
	else if(card_total>11&&card_total<21)
		{
			float  flag = rand()%11;
			if(flag>5)
				return false;
			else
				return true;
		}
	if(card_total>=21)
		return true;
	return true;
}
class RandomGreenPlayer:public RandomPlayer{
	public:
	RandomGreenPlayer();
	~RandomGreenPlayer();
};
class RandomBlackPlayer:public RandomPlayer{
	public:
	RandomBlackPlayer();
	~RandomBlackPlayer();
};
class RandomBluePlayer:public RandomPlayer{
	public:
	RandomBluePlayer();
	~RandomBluePlayer();
};
class RandomRedPlayer:public RandomPlayer{
	public:
	RandomRedPlayer();
	~RandomRedPlayer();
};

RandomGreenPlayer::RandomGreenPlayer(){
	card_total = 0; //needs to be set because will ++
	bet = 0;
	money = 0;
}
RandomGreenPlayer::~RandomGreenPlayer(){

}
RandomRedPlayer::RandomRedPlayer(){
	card_total = 0; //needs to be set because will ++
	bet = 0;
	money = 0;
}
RandomRedPlayer::~RandomRedPlayer(){
	
}
RandomBluePlayer::RandomBluePlayer(){
	card_total = 0; //needs to be set because will ++
	bet = 0;
	money = 0;
}
RandomBluePlayer::~RandomBluePlayer(){
	
}
RandomBlackPlayer::RandomBlackPlayer(){
	card_total = 0; //needs to be set because will ++
	bet = 0;
	money = 0;
}
RandomBlackPlayer::~RandomBlackPlayer(){
	
}